import extcolors as ji
colors, pixel_count = ji.extract("trial.jpg")
print(colors)
print(pixel_count)
print((colors[0]))
print((colors[0][0]))
print((colors[0][0][0]))



#5*2 banner
#4*3 standee

#255 124 124 - last Fourth 3.9-4.2
#255 160 69  - last sixth  3.3-3.6
