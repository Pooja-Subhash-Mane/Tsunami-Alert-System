import cv2
import extcolors as ji
cap = cv2.VideoCapture("tsunamiwave.mp4")
while True:
    ret, frame = cap.read()

    if not ret:
        cap = cv2.VideoCapture("tsunamiwave.mp4")
        continue