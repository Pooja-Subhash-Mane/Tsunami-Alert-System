IplImage* skipNFrames(CvCapture* capture, int n)
{
    for(int i = 0; i < n; ++i)
    {
        if(cvQueryFrame(capture) == NULL)
        {
            return NULL;
        }
    }

    return cvQueryFrame(capture);
}


int main(int argc, char* argv[])
{
    CvCapture* capture = cvCaptureFromFile("../opencv-root/samples/c/tree.avi");

    IplImage* frame = NULL;
    do
    {
        frame = skipNFrames(capture, 4);
        cvNamedWindow("frame", CV_WINDOW_AUTOSIZE);
        cvShowImage("frame", frame);
        cvWaitKey(100);
    } while( frame != NULL );

    cvReleaseCapture(&capture);
    cvDestroyWindow("frame");
    cvReleaseImage(&frame);

    return 0;
}