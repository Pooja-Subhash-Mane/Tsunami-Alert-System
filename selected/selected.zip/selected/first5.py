import cv2
import time
import numpy as np
#import Image

# Function to extract frames
def FrameCapture(path):
    # Path to video file
    vidObj = cv2.VideoCapture(path)

    # Used as counter variable
    time.sleep(2)
    count = 0

    # checks whether frames were extracted
    success = 1

    while success:
        # vidObj object calls read
        # function extract frames
        image: object
        success, image = vidObj.read()

        # Saves the frames with frame-count

        cv2.imwrite("frame%d.jpg" % count, image)
       # im_resized = cv2.resize(image, (224, 224), interpolation=cv2.INTER_LINEAR)
        #cv2.imshow('dst_rt', image)
        #image = Image.open("frame%d.jpg" % count, image)
        #image.show()

        #img = np.zeros((46341, 46341))
        #image = cv2.resize(image, (0, 0), fx=1, fy=1, interpolation=cv2.INTER_CUBIC)
        count += 1


# Driver Code
if __name__ == '__main__':
    # Calling the function
    FrameCapture("tsunamiwave.mp4")
