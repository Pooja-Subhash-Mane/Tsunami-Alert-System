import pyrebase

config = {
'apiKey' : "AIzaSyAi3gP2MNwvzdlcvcaMuewc8zoQMDQltow",
'authDomain': "test-3f09a.firebaseapp.com",
'databaseURL': "https://test-3f09a.firebaseio.com",
'projectId': "test-3f09a",
'storageBucket': "test-3f09a.appspot.com",
'messagingSenderId': "928354029774"
}

firebase = pyrebase.initialize_app(config)
firebase.database().child("RealTime Node").child("Mane").set("3");



import extcolors as ji
colors, pixel_count = ji.extract("frameASHWAMEDHA121.jpg")
print(type(colors))
print(len(colors))
for x in colors:
  """print(x[0][0])
  print(x[0][1])
  print(x[0][2])"""
  if((x[0][0] == 246 and x[0][1]==157 and x[0][2]==73) or (x[0][0] == 213 and x[0][1]==254 and x[0][2]==160) or (x[0][0] == 249 and x[0][1]==219 and x[0][2]==105) or (x[0][0] == 247 and x[0][1]==220 and x[0][2]==105)):
     print('alert there')
     break

"""print(colors)
print(pixel_count)
print((colors[0]))
print((colors[0][0]))
print((colors[0][0][0]))

print("\n")
if(colors[0][0][0])"""



#5*2 banner
#4*3 standee

#255 124 124 - last Fourth 3.9-4.2
#255 160 69  - last sixth  3.3-3.6
